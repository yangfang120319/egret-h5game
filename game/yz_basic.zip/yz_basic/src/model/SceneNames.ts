/**
 *
 * @场景名称
 *
 */
class SceneNames {
    static START: string = "start";//开始
    static LOADING: string = "loading";//加载
}
