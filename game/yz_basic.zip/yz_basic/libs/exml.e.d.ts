declare class SceneLoadingSkin extends eui.Skin{
}
declare class SceneStartSkin extends eui.Skin{
}
