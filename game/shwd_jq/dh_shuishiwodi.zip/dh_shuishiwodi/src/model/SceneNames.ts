/**
 *
 * @场景名称
 *
 */
class SceneNames {
    static START: string = "start";//开始
    static LOADING: string = "loading";//加载
    static RANK: string = "rank";//排行榜
    static GAME: string = "game";//游戏
}
