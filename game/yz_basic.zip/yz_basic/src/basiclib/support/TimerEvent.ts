/**
 *
 * @author 
 *
 */
module basic {
    export class TimerEvent extends egret.Event{
        //定义变量
        static TIMER: string = "timer";
        static TIMER_COMPLETE: string = "timer_complete";
	}
}
