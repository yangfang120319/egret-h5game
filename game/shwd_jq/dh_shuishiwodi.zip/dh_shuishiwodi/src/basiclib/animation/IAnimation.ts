/**
 * Created by admin on 2014/12/9.
 */

module basic{
	export interface IAnimation{
		play():void;
		stop():void;
	}
}
