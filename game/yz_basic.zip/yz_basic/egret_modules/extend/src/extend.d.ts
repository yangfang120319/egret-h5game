/**
 * Created by rockyl on 15/12/21.
 */

declare function showQrCode(url,_top,_height);
declare function hideQrCode();