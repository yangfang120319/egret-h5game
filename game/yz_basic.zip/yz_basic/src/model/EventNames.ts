/**
 *
 * @事件名称
 *
 */
class EventNames {
    //界面事件
    static SHOW_TIPS: string = "show_tips";
    static SHOW_START: string = "show_start";
    static LOADING_PROGRESS: string = "loading_progress";
}