/**
 *
 * @显示界面
 *
 */
class UserData {
    //定义变量
    static User_Id: number = 3;
    static User_Sex: number = 0;
    static User_Name: string = "";
    static User_Head: string = "";
    static User_Gold: number = 25862;
    static User_Level: number = 28;

    //用户每周数据
    static Week_Level: number;
    static Week_Gold: number;
    static User_AddLevel: number;
}
