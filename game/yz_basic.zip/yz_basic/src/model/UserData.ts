/**
 *
 * @显示界面
 *
 */
class UserData {
    //定义变量
    static User_Id: number = 1;
    static User_Sex: number = 0;
    static User_Name: string = "小明";
    static User_Head: string = "";
    static User_Phone: string = "";
    static User_Gold: number = 12300;
    static User_SaveGold: number = 10000;
}
