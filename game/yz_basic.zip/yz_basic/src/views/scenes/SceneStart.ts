/**
 *
 * @开始界面
 *
 */
class SceneStart extends basic.SceneBase {
    //定义变量
    
    //定义界面
    public constructor() {
        super();

        //定义界面
        this.skinName = SceneStartSkin;
        
        
    }
    
    //注册侦听
    beforeShow(params: any): void {
        
    }

    //注销侦听
    beforeHide(): void {
        
    }





    onShowPlace():void{
        console.log(basic.StageProxy.height);
    }
    
}
