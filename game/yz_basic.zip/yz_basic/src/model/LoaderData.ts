/**
 *
 * @加载数据
 *
 */
class LoaderData {
    //定义变量
    static is_LoginEnd: Boolean = false;
    static is_ThemeLoadEnd: Boolean = false;
    static is_Loading_LoadEnd: Boolean = false;
    static is_Start_LoadEnd: Boolean = false;
    static is_Start_Show: Boolean = false;
}
