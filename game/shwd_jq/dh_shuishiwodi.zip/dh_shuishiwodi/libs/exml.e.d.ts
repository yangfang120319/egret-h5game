declare class GameChatSkin extends eui.Skin{
}
declare class GameOrderSkin extends eui.Skin{
}
declare class GameReadySkin extends eui.Skin{
}
declare class GameTopSkin extends eui.Skin{
}
declare class GameVoteSkin extends eui.Skin{
}
declare class HeadSkin extends eui.Skin{
}
declare class StartMsgSkin extends eui.Skin{
}
declare class TipsSkin extends eui.Skin{
}
declare class Panel_GameDescriptionSkin extends eui.Skin{
}
declare class Panel_GameInviteSkin extends eui.Skin{
}
declare class Panel_GameOverSkin extends eui.Skin{
}
declare class Panel_GameWordSkin extends eui.Skin{
}
declare class Panel_SearchRoomSkin extends eui.Skin{
}
declare class SceneGameSkin extends eui.Skin{
}
declare class SceneLoadingSkin extends eui.Skin{
}
declare class SceneRankingSkin extends eui.Skin{
}
declare class SceneStartSkin extends eui.Skin{
}
declare class LiZiSkin extends eui.Skin{
}
declare class LoadingProgressBarSkin extends eui.Skin{
}
declare class TabBarRankingSkin extends eui.Skin{
}
declare class Item_GameChatSkin extends eui.Skin{
}
declare class Item_RankinglistSkin extends eui.Skin{
}
